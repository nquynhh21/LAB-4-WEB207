var app = angular.module("myapp",[]);
            app.controller("myctrl", function ($scope){
                //cung cấp thông tin sinh viên ở đây
                $scope.student = [
                {
                    fullname : "Nhu Quynh",
                    birthday : "21-01-2004",
                    gender : "Nu",
                    photo : "Bai3/nqcvv.jpg",
                    mark : 8.5,
                },
                {
                     fullname : "Nhu Quynh",
                     birthday : "21-01-2004",
                     gender : "Nu",
                     photo : "Bai3/nqcvv.jpg",
                     mark : 8.5,
                },
                {
                    fullname : "Nguyễn Nhu Quynh ",
                    birthday: "9-1-2004",
                    gender : "Nữ",
                    photo: "Bai3/quan.jpg",
                    mark: 9
                },
            ];
            })