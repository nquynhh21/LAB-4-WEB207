var app = angular.module("myapp",[]);
            app.controller("myctrl", function ($scope){
                //cung cấp thông tin sinh viên ở đây
                $scope.student = {
                    fullname : "Nhu Quynh",
                    birthday : "21-01-2004",
                    gender : "Nu",
                    photo : "Bai2/nqcvv.jpg",
                    mark : 8.5,
                }
            })