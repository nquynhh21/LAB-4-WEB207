var app= angular.module("demoapp", []);

app.controller("ctrlDemo", function($scope){
    $scope.number1 = 0;
    $scope.number2 = 0;
    $scope.handleClick= function(){
        $scope.total = parseInt($scope.number1) + parseInt($scope.number2)
    }
});